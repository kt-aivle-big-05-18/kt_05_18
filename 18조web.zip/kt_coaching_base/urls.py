"""
URL configuration for kt_coaching_base project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render
from captcha import urls as captcha_urls
from rpg import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("common.urls")),
    path("rpg/", include("rpg.urls")),
    path("account/", include("account.urls")),
    path("mypage/", include("mypage.urls")),
    path("analysis/", include("analysis.urls")),
    path("community/", include("community.urls")),
    path("admin_page/", include("admin_page.urls")),
    path('captcha/', include(captcha_urls)),
    path('grow_practice/', include('grow_practice.urls')),
]
